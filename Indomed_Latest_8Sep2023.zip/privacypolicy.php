<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Indomed Educare | Best Consultancy To Study Abroad For MBBS</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta propert="og:title" name="title" content="Indomed Educare | Best Consultancy To Study Abroad For MBBS">
    <meta name="keywords" content="best consultancy to study abroad for mbbs, best overseas consultancy, mbbs abroad consultancy india, study mbbs abroad consultancy">
    <meta name="description" content="Indomed Educare - With over 14+ experience in the field, Indomed Educare is transforming the dream of many aspiring students who wish to study MBBS abroad become doctors.">
    <meta property="og:image" content="https://indomededucare.com/img/IndoMed-Educare.png" />

    <link rel="canonical" href="https://www.indomededucare.com/about.php" />

    <!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
    new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
    j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
    'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
    })(window,document,'script','dataLayer','GTM-PGW23P6');</script>
    <!-- End Google Tag Manager -->
    <!-- Favicon -->
    <link href="img/favicon.png" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;500;600&family=Rubik:wght@500;600;700&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
    <!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-G561WRYQG8"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-G561WRYQG8');
</script>
</head>

<body>
 

    <!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-PGW23P6"
    height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->

    <!-- Topbar Start -->
    <?php include 'include/header.php';?>

    <!-- Topbar End -->


    <!-- Navbar Start -->
    <?php include 'include/menu.php';?>

    <!-- Navbar End -->


       <!-- Page Header Start -->
 
    <!-- Page Header End -->


    <!-- Privacy policy Start -->
    <div class="container-xxl py-5">
        <div class="container">
        <h2 class="display-5 mb-4">Privacy Policy</h2>

            <div class="row g-5">
                <div class="col-lg-12 wow fadeIn" data-wow-delay="0.5s">
                    <p class="mb-4 para">At Indomed Educare, we have faith in effortlessness, genuineness, and discipline. To assist you with getting an outline of how we ensure that Indomed Educare site is ok for everybody, how we gather and interaction your information, and how we shield you and ourselves from accidental utilization of our assets and coming about results, we have arranged this convenient aide in regards to our Agreements, Security Strategy, and Disclaimer.</p>
                    <p><strong>Agreements :</strong></p>
                    <ul>
                        <li>Indomed Educare Logo and all types of content put on this site are the restrictive property of Indomed Educare and can't be utilized without our earlier authorization. Utilizing our licensed innovation without approval will welcome a lawful game-plan.</li>
                        <li>You won't involve any of the assets accessible on this site for unlawful or pernicious purposes.</li>
                        <li>While associating with others on the site, either through the contact structure/live talk/some other medium accessible on the site occasionally, you will remain conscious.</li>
                        <li>In the event of emerging of any debate, the matter will be settled as per the tradition that must be adhered to.</li>
                        <li>Snippets of data contained on this site might incorporate connections to outsider sites/mediums/assets. We assume a sense of ownership with your utilization of any of those sites/mediums/assets.</li>
                    </ul>
                    <p class="mb-4"> The above agreements are set up to make a sound and safe experience for yourself and every one of the guests of this site. On the off chance that you don't wish to be complying with something very similar, you might leave this site right away.</p>
                    <p><strong>Security Strategy</strong></p>

                    <p class="mb-4"> By utilizing a structure including contact/application/request structure, you might decide to give your own subtleties to us, including your contact subtleties. These subtleties empower us to reach you and help with your profession. To hit you up, we share your contact subtleties with our group of guides in a got, innovation supported climate. None of your information is imparted to outcasts or different associations at any expense, aside from when expected under the law. All the individual data and client information submitted to us are remained careful in our safe data set.</p>
                    <p><strong>Disclaimer</strong></p>
                    
                    <p class="mb-4"> All the data gave on the site of Indomed Educare is ready with care and depending on valid sources and is consistent with the best of our insight and conviction. In any case, something very similar, not the slightest bit, will comprise proficient exhortation or consultancy. We assume no liability/obligation, either communicated/suggested, either money related or of some other kind, for the results that might emerge by utilizing the data gave on this site.</p>

                </div>

            </div>
        </div>
    </div>
    <!-- Privacy Policy End -->




    <?php include 'include/footer.php';?>
</body>

</html>