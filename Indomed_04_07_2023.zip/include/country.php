<div class="container-fluid bg-dark pt-5 my-5 px-0">
        <div class="text-center mx-auto mt-5 wow fadeIn" data-wow-delay="0.1s" style="max-width: 600px;">
            <h2 class="display-5 mb-5">Best countries to study MBBS Abroad </h2>
        </div>
        <div class="owl-carousel project-carousel wow fadeIn" data-wow-delay="0.1s">
        <a class="project-item" href="philippines.php">
                <img class="img-fluid" src="img/mbbs in philippines.webp" alt="indomed educare - study mbbs in philippines">
                <div class="project-title">
                    <h5 class="ctitle mb-0">Philippines</h5>
                </div>
            </a>
            <a class="project-item" href="china.php">
                <img class="img-fluid" src="img/Study MBBS Abroad Consultancy in India,.,..webp" alt="study MBBS abroad in China">
                <div class="project-title">
                    <h5 class="ctitle mb-0">China</h5>
                </div>
            </a>
            <a class="project-item" href="russia.php">
                <img class="img-fluid" src="img/mbbs in russia.webp" alt="study MBBS abroad in russia - Indomed Educare">
                <div class="project-title">
                    <h5 class="ctitle mb-0">Russia</h5>
                </div>
            </a>
            <a class="project-item" href="georgia.php">
                <img class="img-fluid" src="img/mbbs in georgia.webp" alt="Indomed Educare - study MBBS in Georgia">
                <div class="project-title">
                    <h5 class="ctitle mb-0">Georgia</h5>
                </div>
            </a>
            <a class="project-item" href="us.php">
                <img class="img-fluid" src="img/kazak.jpg" alt="Indomed Educare - study mbbs in ukraine">
                <div class="project-title">
                    <h5 class="ctitle mb-0">Kazakhstan</h5>
                </div>
            </a>
            <a class="project-item" href="uk.php">
                <img class="img-fluid" src="img/mbbs in uk.webp" alt="indomed educare - study mbbs in uk">
                <div class="project-title">
                    <h5 class="ctitle mb-0">UK</h5>
                </div>
            </a>
            <!-- <a class="project-item" href="canada.php">
                <img class="img-fluid" src="img/mbbs in Canada.jpg" alt="Indomed Educare - study mbbs in ukraine">
                <div class="project-title">
                    <h5 class="ctitle mb-0">Canada</h5>
                </div>
            </a> -->
        </div>
    </div>