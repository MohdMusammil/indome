<html>
<head>
</head>
<body>
									 <!--footer section start-->
										<footer>
										   <p>&copy 2023 IndoMed . All Rights Reserved </p>
										</footer>
									<!--footer section end-->
</body>
</html>