<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>IndomedEducare|Leading Study MBBS Abroad Consultancy</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">
    <meta property="og:image" content="https://indomededucare.com/img/IndoMed-Educare.png" />

    <link rel="canonical" href="https://www.indomededucare.com/philippines.php" />
    <!-- Google Tag Manager -->
    <script>
      (function(w, d, s, l, i) {
        w[l] = w[l] || [];
        w[l].push({
          'gtm.start': new Date().getTime(),
          event: 'gtm.js'
        });
        var f = d.getElementsByTagName(s)[0],
          j = d.createElement(s),
          dl = l != 'dataLayer' ? '&l=' + l : '';
        j.async = true;
        j.src = 'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
        f.parentNode.insertBefore(j, f);
      })(window, document, 'script', 'dataLayer', 'GTM-PGW23P6');
    </script>
    <!-- End Google Tag Manager -->
    <!-- Favicon -->
    <link href="img/favicon.png" rel="icon">
    <link rel="stylesheet" href="css/w3.css">
    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;500;600&family=Rubik:wght@500;600;700&display=swap" rel="stylesheet">
    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">
    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">

    <!-- Google tag (gtag.js) -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-G561WRYQG8"></script>
    <script>
      window.dataLayer = window.dataLayer || [];

      function gtag() {
        dataLayer.push(arguments);
      }
      gtag('js', new Date());
      gtag('config', 'G-G561WRYQG8');
    </script>
  </head>
  <body>
    <!-- Google Tag Manager (noscript) -->
    <noscript>
      <iframe src="https://www.googletagmanager.com/ns.html?id=GTM-PGW23P6" height="0" width="0" style="display:none;visibility:hidden"></iframe>
    </noscript>
    <!-- End Google Tag Manager (noscript) -->
    <!-- Topbar Start --> <?php include 'include/header.php';?>
    <!-- Topbar End -->
    <!-- Navbar Start --> <?php include 'include/menu.php';?>
    <!-- Navbar End -->
    <!-- Page Header Start -->
    <!-- <div class="container-fluid page-header py-5 mb-5 wow fadeIn" data-wow-delay="0.1s">
      <div class="container py-5">
        <h1 class="display-3 text-white animated slideInRight">Study MBBS in Philippines</h1>
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb animated slideInRight mb-0">
            <li class="breadcrumb-item">
              <a href="index.php">Home</a>
            </li>
            <li class="breadcrumb-item">
              <a href="#">Pages</a>
            </li>
            <li class="breadcrumb-item active" aria-current="page">Study MBBS in Philippines</li>
          </ol>
        </nav>
      </div>
    </div> -->
    <!-- Page Header End -->
    <!-- Intro Start -->
   
    <div class="container">
    <div class="text-center mx-auto pb-4 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 600px;">
                <!-- <p class="fw-medium text-uppercase text-primary mb-2">What we offer</p> --><br>
                <h2 class="display-5 mb-4">All Blogs</h2>
            </div>
                <div class="row mt-n5">
                  
                    <div class="col-md-6 col-lg-4 mt-5 wow fadeInUp" data-wow-delay=".2s" style="visibility: visible; animation-delay: 0.2s; animation-name: fadeInUp;   box-shadow: 3px 0px 2px rgba(0,0,0,0.5);">
                        <div class="blog-grid">
                            <div class="blog-grid-img position-relative"><a href="study-MBBS-without-passing-the-NEET.php"><img alt="img" src="img/Blogs/study_MBBS_without_passing_the_NEET_exam.jpg"></a></div>
                            <div class="blog-grid-text p-4">
                                <h3 class="h5 mb-3"><a href="study-MBBS-without-passing-the-NEET.php">Is it possible to study MBBS without passing the NEET exam?</a></h3>
                                <p class="display-30">This article explores the possibility of pursuing an MBBS without clearing or passing the NEET examination </p>
                                <div class="meta meta-style2">
                                    <ul>
                                        <li><a href="#!"><i class="fas fa-calendar-alt"></i> 10 Jul, <script>document.write(new Date().getFullYear())</script></a></li>
                                        <li><a href="#!"><i class="fas fa-user"></i> User</a></li>
                                        <li><a href="#!"><i class="fas fa-comments"></i> 11</a></li>
                                    </ul>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4 mt-5 wow fadeInUp" data-wow-delay=".4s" style="visibility: visible; animation-delay: 0.4s; animation-name: fadeInUp;   box-shadow: 3px 0px 2px rgba(0,0,0,0.5); ">
                        <div class="blog-grid">
                            <div class="blog-grid-img position-relative"><a href="study-MBBS-with-low-NEET-score.php"><img alt="img" src="img/Blogs/MBBS_with_low_NEET_score.jpg"></a></div>
                            <div class="blog-grid-text p-4">
                                <h3 class="h5 mb-3"><a href="study-MBBS-with-low-NEET-score.php">Is it possible to study MBBS with a low NEET score?</a></h3>
                                <p class="display-30">Yes, students with low NEET scores need not wait for another year to pursue their MBBS studies.</p><br>
                                <div class="meta meta-style2">
                                    <ul>
                                        <li><a href="#!"><i class="fas fa-calendar-alt"></i> 1 Aug, <script>document.write(new Date().getFullYear())</script></a></li>
                                        <li><a href="#!"><i class="fas fa-user"></i> User</a></li>
                                        <li><a href="#!"><i class="fas fa-comments"></i> 7</a></li>
                                    </ul>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4 mt-5 wow fadeInUp" data-wow-delay=".6s" style="visibility: visible; animation-delay: 0.6s; animation-name: fadeInUp;   box-shadow: 3px 0px 2px rgba(0,0,0,0.5); ">
                        <div class="blog-grid">
                            <div class="blog-grid-img position-relative"><a href="guideline-to-indianstudents-for-study-mbbs-abroad.php"><img alt="img" src="img/Blogs/Guidelines_to_Indian_Students_for_Study_MBBS_Abroad1.jpg"></a></div>
                            <div class="blog-grid-text p-4">
                                <h3 class="h5 mb-3"><a href="guideline-to-indianstudents-for-study-mbbs-abroad.php">Guidelines to Indian Students for Study MBBS Abroad</a></h3>
                                <p class="display-30">If you're excited about chasing your dream of studying abroad, this article is here to help!</p>
                                <div class="meta meta-style2">
                                    <ul>
                                        <li><a href="#!"><i class="fas fa-calendar-alt"></i> 16 May, <script>document.write(new Date().getFullYear())</script></a></li>
                                        <li><a href="#!"><i class="fas fa-user"></i> User</a></li>
                                        <li><a href="#!"><i class="fas fa-comments"></i> 13</a></li>
                                    </ul>
                                </div>

                            </div>
                        </div>
                    </div>
                    <!-- <div class="col-md-6 col-lg-4 mt-5 wow fadeInUp" data-wow-delay=".8s" style="visibility: visible; animation-delay: 0.8s; animation-name: fadeInUp;">
                        <div class="blog-grid">
                            <div class="blog-grid-img position-relative"><img alt="img" src="https://www.bootdey.com/image/480x480/00FFFF/000000"></div>
                            <div class="blog-grid-text p-4">
                                <h3 class="h5 mb-3"><a href="#!">Results professional report</a></h3>
                                <p class="display-30">Exercitation ullamco laboris nisi ut aliquip ex ea commodo.</p>
                                <div class="meta meta-style2">
                                    <ul>
                                        <li><a href="#!"><i class="fas fa-calendar-alt"></i> 02 Apr, <script>document.write(new Date().getFullYear())</script>2022</a></li>
                                        <li><a href="#!"><i class="fas fa-user"></i> User</a></li>
                                        <li><a href="#!"><i class="fas fa-comments"></i> 38</a></li>
                                    </ul>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4 mt-5 wow fadeInUp" data-wow-delay="1s" style="visibility: visible; animation-delay: 1s; animation-name: fadeInUp;">
                        <div class="blog-grid">
                            <div class="blog-grid-img position-relative"><img alt="img" src="https://www.bootdey.com/image/480x480/00FFFF/000000"></div>
                            <div class="blog-grid-text p-4">
                                <h3 class="h5 mb-3"><a href="#!">Business strategy concept</a></h3>
                                <p class="display-30">Exercitation ullamco laboris nisi ut aliquip ex ea commodo.</p>
                                <div class="meta meta-style2">
                                    <ul>
                                        <li><a href="#!"><i class="fas fa-calendar-alt"></i> 25 Mar, <script>document.write(new Date().getFullYear())</script>2022</a></li>
                                        <li><a href="#!"><i class="fas fa-user"></i> User</a></li>
                                        <li><a href="#!"><i class="fas fa-comments"></i> 68</a></li>
                                    </ul>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4 mt-5 wow fadeInUp" data-wow-delay="1.2s" style="visibility: visible; animation-delay: 1.2s; animation-name: fadeInUp;">
                        <div class="blog-grid">
                            <div class="blog-grid-img position-relative"><img alt="img" src="https://www.bootdey.com/image/480x480/00FFFF/000000"></div>
                            <div class="blog-grid-text p-4">
                                <h3 class="h5 mb-3"><a href="#!">Business people meeting</a></h3>
                                <p class="display-30">Exercitation ullamco laboris nisi ut aliquip ex ea commodo.</p>
                                <div class="meta meta-style2">
                                    <ul>
                                        <li><a href="#!"><i class="fas fa-calendar-alt"></i> 10 Feb, <script>document.write(new Date().getFullYear())</script>2022</a></li>
                                        <li><a href="#!"><i class="fas fa-user"></i> User</a></li>
                                        <li><a href="#!"><i class="fas fa-comments"></i> 58</a></li>
                                    </ul>
                                </div>

                            </div>
                        </div>
                    </div> -->
                </div>
                <div class="row mt-6 wow fadeInUp" data-wow-delay=".6s" style="visibility: visible; animation-delay: 0.6s; animation-name: fadeInUp;">
                    <div class="col-12">
                        <div class="pagination text-small text-uppercase text-extra-dark-gray">
                            <ul>
                                <li><a href="#!"><i class="fas fa-long-arrow-alt-left me-1 d-none d-sm-inline-block"></i> Prev</a></li>
                                <li class="active"><a href="#!">1</a></li>
                                <li><a href="#!">2</a></li>
                                <li><a href="#!">3</a></li>
                                <li><a href="#!">Next <i class="fas fa-long-arrow-alt-right ms-1 d-none d-sm-inline-block"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
</div>







    <!-- Contact End --> <?php include 'include/footer.php';?> <script>
      function openCity(evt, cityName) {
        var i, x, tablinks;
        x = document.getElementsByClassName("city");
        for (i = 0; i < x.length; i++) {
          x[i].style.display = "none";
        }
        tablinks = document.getElementsByClassName("tablink");
        for (i = 0; i < x.length; i++) {
          tablinks[i].className = tablinks[i].className.replace(" w3-border-red", "");
        }
        document.getElementById(cityName).style.display = "block";
        evt.currentTarget.firstElementChild.className += " w3-border-red";
      }
    </script>
   
  </body>
</html>